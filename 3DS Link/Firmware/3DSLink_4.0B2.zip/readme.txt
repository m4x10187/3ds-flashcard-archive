﻿English Version

[Instructions]
Change Log:
1.Support Multi-ROM
2.Support FAT32&exFAT 
3.Support up to 32GB tf card
4.Support online play(to be tested)
5.Because of the 3ds system's updating, emuNand is delayed.

[User Instruction]
1. Copy the "launcher.data" to your 3DS SD card.Also copy the WoodR4 kernel to the microsd card.
   Running into Wood menu, press "START" to select "3DS Setup" , and then press "B" to intall "3DS Setup"
   After the programing verify finished , press "HOME" to return to main menu.
   Go to "setting"->"other setting"->"profile"->"Nintendo DS Profile".Then,you have entered 3DSlink MODE.
2. Format the micro sd card in "FAT32" or "exFAT"(exFAT should format under window vista/WIN7/WIN8...)
3. Copy some 3ds roms to Micro sd card
4. Insert microsd card into your 3DSlink(the 3DS card) and then insert it into the 3DS SLOT
5. The 3ds games list will show on the top screen after you press "KEY_SELECT"
6. The KEY_Left and KEY_Right can be used for selecting game icon, can move 1 step by each pressing
7. The KEY_L and KEY_R can move game icons with 5 steps by each pressing
8. Pressing KEY_A to confirm your choice
9. Then the game icon will display, you can press KEY_A to enter to play the 3ds game

[FAQ]
Please follow the steps below if you meet such causes.
Q: Game icon canot display after selecting a game like step 8,how can I do then?
A: For the game icons cannot display, please do as:
1. Press KEY_SELECT, and then press KEY_B
2. The games list will show on the top screen after you press "KEY_SELECT", choose one of the games you like,
   press KEY_A to make the game icon display

OR

1. Pull the 3DS card out from SLOT, then insert into it again
2. The games list will show on the top screen after you press "KEY_SELECT", choose one of the games you like,
   press KEY_A to make the game icon display

Q: If the Microsd card has been formated into FAT32, then how to process the large size game of 4GB or 4GB+?
A: Please follow as the belowing:
1. Split the large size game into XYZ.3D0,XYZ.3D1...through the tool "splitter.exe"
2. Copy the XYZ.3D0 to microsd card and then XYZ.3D1...
OR
Format your microsd card in exFAT which can support the 4GB large game size directly

[Notice]
For the limitation of memory space, the MH4 patch cannot be added in this update, 
sure you can play the MH4 through Deluxe Firmware 4.0B1


------------------------------------------------------------------------------------------------------

中文版

[使用说明]
更新日志:
1.支持一卡多游
2.支持FAT32 & exFAT文件系统 (exFAT需要Windows vista格式化tf卡,请你们测试一下)
3.支持32GB等大容量TF卡
4.支持对战
5.EMUNAND即将支持

[操作步骤]
1.破解步骤和以前版本一样,此处不做介绍
2.将TF卡格式化成FAT32或者exFAT文件系统
3.把相关的3DS ROM拷贝到TF卡的根目录
4.TF插入3dslink, 把3DS卡插入主机
5.进入破解模式之后,按KEY_Select键,游戏列表出现
6.KEY_Left和KEY_Right,左右移动选择图标,每次跳动1格
7.KEY_L和KEY_R,每次可以跳5格
8.选好游戏,按KEY_A键,进入游戏
9.选择的游戏图标出现之后,再按KEY_A键,进入游戏


[注意事项]
如果出现以下问题,请按照下面的步骤操作:
Q.上述操作步骤的第8步,按KEY_A键,选择了一个游戏,但是游戏的图标没有出现,怎么办?
A:如果游戏图标没有出现,请按照以下步骤操作:
1.请按KEY_Select键,再按KEY_B
2.按KEY_Select键,游戏列表出现,选择相关的游戏,再按KEY_A键,游戏图标会出现

或者按照以下步骤:
1.把3DS卡从卡槽里拔出来,再插进去
2.按KEY_Select键,游戏列表出现,选择相关的游戏,再按KEY_A键,游戏图标会出现

如果TF卡被格式化成了FAT32文件系统,如何处理4GB或4GB以上的游戏?
A:请按照以下步骤操作:
1.采用splitter.exe将这个游戏分割成xxx.3D0,xxx3D1等小文件
2.首先把xxx.3D0拷贝到tf卡,再拷贝xxx3D1等等.

或者把tf卡格式化成exFAT文件系统,exFAT文件系统可以支持4GB的游戏

[告示]
由于内存空间有限,MH4的补丁没有加入到此版本当中.如果用户要玩MH4,请采用V4.0B1版本


