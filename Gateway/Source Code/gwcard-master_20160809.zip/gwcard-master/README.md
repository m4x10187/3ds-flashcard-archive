# gwcard

This repository contains source files for initializing and utilizing protocol in Gateway 3DS cartridges, and by derivation, Supercard DSTWO+ and possibly other clones.
