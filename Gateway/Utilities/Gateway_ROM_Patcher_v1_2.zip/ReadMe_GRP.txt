    .____________________________________________________________________.
    |::::'                                                               |
    |::'                                                                 |
    |'                                                                   |
    |           _______/_ ________   _/_________________/________        |
    |          /   ___/__/    ___/___/  _     /   _    /  _     /        |
    |         _\____     \   /      /   /____/_   /   /   /____/_        |
     ______  (___________/_________/__________/__/___/__________/        |
    _\_    \ _/________/____     _/_______   ____     _____  _/________ _____/_
   /  _\  _/_/   _    /   __|____/  _    /___\_  \   /  __/__/   _    //  __/__
  /   \     \    /___/_   \     /   /___/_   _/   \__\__     \   /___/_\__     \
 /_____\     \________/_________\________/___\_____/_________/________/________/
        \______/
    |                                                                   .|
    |                                                                 .::|
    |                            _____________                      .::::|
    '-----------[NDS/DSi]--------\           /----------[3DS]------------'
                                  \         /
                                   \       /
                                    \     /
                                     \   /
                                      \ /
                                       '
  __:______\                                                       /______:__
  __:_______                GRP - Gateway Rom Patcher              _______:__
    :      /______________                           ______________\      :
                          )___________   ___________(
                                      \ /

--------
+ About
--------
Gateway's cartridge dumper (firmware v2.1 and later ones) injects few additionnal bytes into 3DS ROM headers.
These data are used by flashcards to enable games' online features.
"Gateway ROM patcher" is a Windows utility which fastly manage this header area if you want to share,
remove, or inject your own data into 3DS ROMs.
Requirements: PC running Windows, .NET framework 4.0 installed.

-------------
+ Disclaimer
-------------
By using this software, you understand and accept that:
- To play backups online (with an original or modifed header) will never be totally safe.
- To use a Cartridge ID shared between many people (aka "public ID"), or to use one coming from a single player game, or from another region, can probably increase the ban risks.
- We will not be responsible for any damages or ban of your original game cartridge, 3DS console, Nintendo ID, or whatever.

Important: A first ban wave happened recently, and a majority of banned people reported they were using public headers.
Since the detection method is still unknown, we can't guarantee that a private ID is safer.
Once again, try online play at your own risks.

--------
+ Usage
--------
1) Load a 3DS ROM (.3ds/.3dz)

2) Optional: Tick the checkboxes if you want to create ROM backups, or rename them as .3dz, before doing any operation.

3) Select an operation:
- use "Import" to patch your ROM header with binary file
- use "Export" to export your ROM header as a binary file
- use "Clear" to remove all data from ROM header (header will be filled with 0xFF, as raw cartridge dump format)
- use the "Custom Header" area to manually enter the cart ID and chip ID of your choice. Then press "Apply" to patch these new values to your ROM.
IMPORTANT : read the "Custom Header Details" part below for more information about the public Cart ID, and chip ID generation.

4) Copy the patched ROM to your flashcard, and try your luck online.

------------------------
+ Custom Header Details
------------------------
> Cart ID (16 Bytes): is the Cartridge ID you are going to use online.
Each original game cartridge got its own unique ID. However, some flashcard users are now sharing same IDs to go online.
Even if no ban happened yet at the time we write this doc, we recommend you to better use a private one dumped by yourself (and if possible coming from the game you're playing a backup of).
Gateway Rom Patcher now includes few "public headers" shared by the community, forums, roms, etc. for people who really want to take the risk of using them.
But again, read our disclaimer before playing with fire.

> Chip ID (8 Bytes): is the game chip identifier code composed by: Manufacturer code (1B.) / Chip size (1B.) / Unknown byte (1B.) / Media Type (1B.) / Unknown data (4B.)
Gateway Rom Patcher will pop-up an alert message if the chip ID really seems incorrect. The program can try to fix it, but some components like the manufacturer's value or Unknown data can't be guessed.
- Manufacturer codes details:
All chips of a same title are not necessarily coming from the same manufacturer depending on the continent. For example "Pokemon X JPN" and "Pokemon X EUR" are done by two different chip manufacturers.
With only a ROM file, it's hard to know which manufacturer did your game's chip. So if your patched ROM is not accepted online by using "Macronix" code, we can only advise you to try another one, then retry online play and so on.
From a large batch of games we tested, 3 manufacturers were found and the ratio is approximately: Macronix 90% of the chips / SanDisk 7% / OKI 3%. It should help to go faster in your tests.
- "Unknown byte" details:
Until now we only saw the "unknown byte" taking values "00" or "02". Forcing it to "00" seems to work with every games we tested so far, so you can try it if you really have no idea of what to use here.
- "Unknown data" details:
Unknown usage. They used to be "00" filled for the old games, and recently started to contain news values. First byte is sometimes set to "01", the rest seems "00"ed.

Note that the Cart ID and Chip ID values MUST be valid to play online, or the game will be simply rejected.

------------
+ Changelog
------------

v1.2
For ROMs dumped with the Gateway method, following the Chip ID, 4 more bytes used to be filled only with "00" and GRP was not displaying them (see "Unknown data" above).
Recently some new games are starting to contain values here, so we decided to extend the "Chip ID" area.
- "Chip ID" area has been extended. You can now display/edit 8 bytes instead of just 4.
- "Chip ID auto-dectection" has been modified accordingly.  

v1.1
- "Rename ROM extension to .3dz" checkbox added. If checked, your ROM extension will be automatically renamed to .3dz after patching operations (a header file import, or manual header edit)
- "Ask to create a backup" checkbox is back. If checked, you'll be asked to create a ROM backup before any patching operation (a header import, header clear, manual header edit)
- checkboxes states are saved and will be loaded at next startup
- the "Cart ID" value will now be directly copied to the Custom header area if the "Chip ID" is auto-detected and cartridge ID is empty (avoids a manual copy/paste)
- more info messages are now displayed during the chip ID autofix, to not forget to Apply changes.
credits to iCEQB for some nice ideas :)

v1.0
- Top part of the GUI is now readonly. Manual edit of cart/chip IDs is now in a dedicated section.
- Some public cartridge IDs can be called in app. But again, use them at your own risks.
- Chip ID generator is back. As usual manufacturer can't be guessed so Macronix code will be set by default.
- Automatic ROM backup checkbox has been removed, you're directly working on the original file now.
- Time has been added in logs and more steps are now detailed.

v0.7
- The chip ID autofix is now splitted in two operations: media type fix and chip size fix.
- game serial size fixed
- many wordings changed

------------
+ Thanks to
------------
3Dbrew, Gbatemp community, independent testers and reporters.