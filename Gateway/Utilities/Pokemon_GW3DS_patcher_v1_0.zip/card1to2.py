#!/usr/bin/env python

import os,sys,struct,subprocess
print("\ncard1to2\nby Glitch\nPokemon Moon/Sun specific harcoded GW3DS red card edits by modrobert\n")


if len(sys.argv) < 2:
    print("Error: Need a game ROM file as only argument.\n")
    raw_input("Press any key to continue... ")
    sys.exit()

filename=sys.argv[1]

f=open(filename,"rb+")
MB=0x100000

def num2string(n,size):
	ret=""
	for i in range(size):
		ret+=chr(n & 0xFF)
		n>>=8
	return ret

def string2list(n):
	ret=[0x0]*len(n)
	count=0
	for i in n:
		ret[count]=ord(n[count])
		count+=1
	return ret
	
def endianSwitch(n):
	return n[::-1]

def hex2value(n):
	return int(n.encode("hex"),16)

def grabData(off,size):
	f.seek(off)
	offset=f.read(size)
	return offset

if hex2value(grabData(0x18B,1)):
	f.seek(0x18B)
	f.write(chr(2))
	
f.seek(0x18D)
f.write(chr(2))

if hex2value(grabData(0x18F,1)):
	f.seek(0x18F)
	f.write(chr(2))

if hex2value(grabData(0x1FE,1)):
    print("Patching Anti-Piracy offset: 0x1fe");
    f.seek(0x1FE)
    f.write(chr(0))

dataSize=0
dataSize=hex2value(endianSwitch(grabData(0x300,4)))
saveOffset=(dataSize / MB)*MB+MB
mediaUnitOffset=saveOffset / 0x200

f.seek(0x200)
f.write(num2string(mediaUnitOffset,4))

print("DATASIZE: "+str(hex(dataSize)))
print("NEW CARD2 SAVE OFFSET: "+str(hex(saveOffset)))
print
f.close()
print("Done.\n")
raw_input("Press any key to continue... ")
