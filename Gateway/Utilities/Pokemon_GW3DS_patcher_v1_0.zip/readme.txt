modrobert @ 2016-11-25

I edited a Python script by Glitch to convert the scene releases (.3ds format)
for Pokemon Moon and Sun to work with the Gateway 3DS red card. 

The stuff I found over at gbatemp.net was not working, so had to edit the
script; skip the truncating part, and patch the "Anti-Piracy" 0x1FE offset from
'5' to '0', and some other changes.

If you get a message about corrupt save data, then you can delete the corrupt
save data in game using this key combo; UP (d-pad) + B + X (buttons) and follow
prompts on the screen.

The included Python script should work, but keep in mind this is an ugly hack
only for Pokemon Moon and Sun, don't use this script for other titles. 

