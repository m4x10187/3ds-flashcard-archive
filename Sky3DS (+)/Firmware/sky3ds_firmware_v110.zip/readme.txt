* Sky3DS+ firmware V110 [01/18/2016]

Change logs:
1. Fixed some tiny bugs.
2. Enable you to play new coming games directly, don't need the gamelist.bin any more.

*Instructions:
1. Extract the zip file on a PC, copy the "firmware.bin" and "settings.txt" file into the root directory of your microSD card.
2. Insert the microSD card into sky3DS+, connect your PC and sky3DS+ with a USB cable(come with).
3. The LED red light will turn on about 5 seconds, then turn to the green light and keep flashing around 5 seconds, once the light turn off it means the sky3DS+ has been updated successfully.
Alert: Never unplug the USB cable while the green light keep flashing, it might damage your sky3DS+ card! 4. Delete the "firmware.bin" file in your microSD card.

